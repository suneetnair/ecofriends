// set the password of the website
var password;
var pass = "physis";
password = prompt('Please enter the password to view the page', '');
if (password == pass)
    alert('Correct password, click ok to enter.');
else {
    window.location = "http://wwww.google.com.au"
}